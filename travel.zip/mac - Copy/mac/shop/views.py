from django.shortcuts import render
from .models import Contact
from math import ceil

# Create your views here.
from django.http import HttpResponse

def index(request):
    
    return render(request, 'shop/index.html')

def about(request):
    return render(request, 'shop/about.html')
def contact(request):
    if request.method=="POST":
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        desc = request.POST.get('desc', '')
        contact = Contact(name=name, email=email, phone=phone, desc=desc)
        contact.save()
    return render(request, 'shop/contact.html')
def home(request):
    return render(request, 'shop/home.html')





